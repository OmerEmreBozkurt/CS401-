@echo off

java -jar acdc.jar %1 c.rsf
java -jar mojo.jar c.rsf %2 -fm

del c.rsf




