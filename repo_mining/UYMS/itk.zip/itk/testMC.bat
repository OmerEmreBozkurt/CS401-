@echo off

java -jar rsf2txt.jar %1 dep.txt

java -jar clustering.jar dep.txt c.txt

java -jar txt2rsf.jar c.txt c.rsf
java -jar mojo.jar c.rsf %2 -fm

del dep.txt
del c.txt
del c.rsf
